# docs/source/api/index.rst

============
API Reference
============

This section provides detailed information about the BookingApp API endpoints, request parameters, and response structures.

.. toctree::
   :maxdepth: 2

   account
   booking