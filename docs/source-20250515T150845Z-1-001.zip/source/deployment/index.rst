# docs/source/deployment/index.rst

==============
Deployment Guide
==============

This section provides detailed instructions for deploying the BookingApp system in various environments.

.. toctree::
   :maxdepth: 2

   local
   production