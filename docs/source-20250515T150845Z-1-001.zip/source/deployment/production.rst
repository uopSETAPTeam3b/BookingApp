# docs/source/deployment/production.rst

===================
Production Deployment
===================

This guide will help you deploy the BookingApp system in a production environment.

Prerequisites
------------

Before deploying to production, ensure you have:

1. **A server or hosting environment**: Linux-based VPS, cloud service (AWS, GCP, Azure), etc.
2. **Python 3.10+**: Installed on the server
3. **Domain name**: (Optional but recommended) A registered domain name pointing to your server
4. **SSL certificate**: For HTTPS support (Let's Encrypt recommended)
5. **SMTP credentials**: For sending email notifications

Step 1: Server Setup
------------------

First, ensure your server has the necessary software:

.. code-block:: bash

    # Update package lists
    sudo apt update
    sudo apt upgrade -y

    # Install Python and related tools
    sudo apt install python3 python3-pip python3-venv python3-dev -y

    # Install Nginx for reverse proxy
    sudo apt install nginx -y

    # Install certbot for SSL certificates
    sudo apt install certbot python3-certbot-nginx -y

Step 2: Clone the Repository
--------------------------

Clone the application repository to your server:

.. code-block:: bash

    # Create a directory for the application
    mkdir -p /var/www/bookingapp
    cd /var/www/bookingapp

    # Clone the repository
    git clone https://github.com/uopSETAPTeam3b/BookingApp.git .

Step 3: Set Up Python Environment
------------------------------

Create a virtual environment and install dependencies:

.. code-block:: bash

    # Create virtual environment
    python3 -m venv venv
    source venv/bin/activate

    # Install dependencies
    pip install -r requirement.txt

    # Install additional production dependencies
    pip install gunicorn uvicorn

Step 4: Configure Environment Variables
------------------------------------

Create a `.env` file for sensitive information:

.. code-block:: bash

    # Create .env file
    touch .env

    # Add necessary environment variables
    echo "smtp_username = \"your_email@gmail.com\"" >> .env
    echo "smtp_password = \"your_app_password\"" >> .env

    # Secure the file
    chmod 600 .env

Step 5: Set Up Database
--------------------

For production, you might want to use a more robust database than SQLite:

For SQLite (simpler option):

.. code-block:: bash

    # Create a directory for the database
    mkdir -p /var/www/bookingapp/data
    chmod 755 /var/www/bookingapp/data

    # Modify database path in code or use an environment variable
    # Edit src/database.py to point to the new location

For PostgreSQL (recommended for larger deployments):

.. code-block:: bash

    # Install PostgreSQL
    sudo apt install postgresql postgresql-contrib -y

    # Create a database and user
    sudo -u postgres psql -c "CREATE DATABASE bookingapp;"
    sudo -u postgres psql -c "CREATE USER bookinguser WITH PASSWORD 'secure_password';"
    sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE bookingapp TO bookinguser;"

    # You'll need to modify the database code to use PostgreSQL instead of SQLite

Step 6: Create a Systemd Service
-----------------------------

Create a systemd service file for the application:

.. code-block:: bash

    sudo nano /etc/systemd/system/bookingapp.service

Paste the following content:

.. code-block:: ini

    [Unit]
    Description=BookingApp FastAPI Application
    After=network.target

    [Service]
    User=www-data
    Group=www-data
    WorkingDirectory=/var/www/bookingapp
    Environment="PATH=/var/www/bookingapp/venv/bin"
    EnvironmentFile=/var/www/bookingapp/.env
    ExecStart=/var/www/bookingapp/venv/bin/gunicorn -w 4 -k uvicorn.workers.UvicornWorker src.app:app --bind 0.0.0.0:8000

    [Install]
    WantedBy=multi-user.target

Enable and start the service:

.. code-block:: bash

    sudo systemctl daemon-reload
    sudo systemctl enable bookingapp.service
    sudo systemctl start bookingapp.service
    sudo systemctl status bookingapp.service

Step 7: Configure Nginx as a Reverse Proxy
---------------------------------------

Create an Nginx configuration file:

.. code-block:: bash

    sudo nano /etc/nginx/sites-available/bookingapp

Paste the following content:

.. code-block:: nginx

    server {
        listen 80;
        server_name your-domain.com www.your-domain.com;

        location / {
            proxy_pass http://127.0.0.1:8000;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }

        location /static {
            alias /var/www/bookingapp/static;
        }
    }

Enable the site and restart Nginx:

.. code-block:: bash

    sudo ln -s /etc/nginx/sites-available/bookingapp /etc/nginx/sites-enabled/
    sudo nginx -t
    sudo systemctl restart nginx

Step 8: Set Up SSL with Let's Encrypt
----------------------------------

Secure your site with HTTPS:

.. code-block:: bash

    sudo certbot --nginx -d your-domain.com -d www.your-domain.com

Follow the prompts and certbot will automatically configure Nginx for HTTPS.

Step 9: Set Up Backup System
-------------------------

Implement regular backups for your database:

.. code-block:: bash

    # Create a backup script
    nano /var/www/bookingapp/backup.sh

Add the following content:

.. code-block:: bash

    #!/bin/bash
    TIMESTAMP=$(date +%Y%m%d%H%M%S)
    BACKUP_DIR="/var/backups/bookingapp"
    mkdir -p $BACKUP_DIR

    # For SQLite
    cp /var/www/bookingapp/database.db $BACKUP_DIR/database_$TIMESTAMP.db

    # For PostgreSQL
    # pg_dump -U bookinguser -d bookingapp > $BACKUP_DIR/bookingapp_$TIMESTAMP.sql

    # Rotate backups (keep last 7 days)
    find $BACKUP_DIR -type f -mtime +7 -delete

Make the script executable and set up a cron job:

.. code-block:: bash

    chmod +x /var/www/bookingapp/backup.sh
    sudo crontab -e

Add this line to run backups daily at 2 AM:

.. code-block:: bash

    0 2 * * * /var/www/bookingapp/backup.sh

Step 10: Monitoring Setup
----------------------

For basic monitoring, install and configure a monitoring tool like Prometheus with Grafana or a simpler solution like Monit:

.. code-block:: bash

    # Install Monit
    sudo apt install monit -y

    # Configure Monit
    sudo nano /etc/monit/conf.d/bookingapp

Add this configuration:

.. code-block:: text

    check process bookingapp with pidfile /var/run/bookingapp.pid
      start program = "/bin/systemctl start bookingapp"
      stop program = "/bin/systemctl stop bookingapp"
      if failed host 127.0.0.1 port 8000 protocol http
        request /health
        with timeout 10 seconds
        then restart

    check system $HOST
      if memory usage > 80% for 2 cycles then alert
      if cpu usage (user) > 80% for 2 cycles then alert
      if cpu usage (system) > 30% for 2 cycles then alert

Restart Monit:

.. code-block:: bash

    sudo systemctl restart monit

Security Considerations
--------------------

Enhance security for your production deployment:

1. **Firewall Configuration**:

   .. code-block:: bash

      sudo ufw enable
      sudo ufw allow ssh
      sudo ufw allow http
      sudo ufw allow https
      sudo ufw status

2. **Secure File Permissions**:

   .. code-block:: bash

      sudo chown -R www-data:www-data /var/www/bookingapp
      sudo find /var/www/bookingapp -type d -exec chmod 755 {} \;
      sudo find /var/www/bookingapp -type f -exec chmod 644 {} \;
      sudo chmod 640 /var/www/bookingapp/.env

3. **Regular Updates**:

   .. code-block:: bash

      # Add to crontab
      0 3 * * 0 apt-get update && apt-get upgrade -y

4. **Fail2Ban for Brute Force Protection**:

   .. code-block:: bash

      sudo apt install fail2ban -y
      sudo systemctl enable fail2ban
      sudo systemctl start fail2ban

Scaling Considerations
-------------------

If your application needs to handle more traffic:

1. **Increase Worker Processes**:
   
   Modify the gunicorn command in your systemd service:

   .. code-block:: bash

      ExecStart=/var/www/bookingapp/venv/bin/gunicorn -w 8 -k uvicorn.workers.UvicornWorker src.app:app --bind 0.0.0.0:8000

2. **Load Balancing**:
   
   Set up multiple application servers behind a load balancer.

3. **Caching Layer**:
   
   Implement Redis or Memcached for caching.

4. **Database Optimization**:
   
   Migrate to a more robust database system like PostgreSQL and optimize queries.

Maintenance Procedures
-------------------

Regular maintenance tasks:

1. **Log Rotation**:

   .. code-block:: bash

      sudo nano /etc/logrotate.d/bookingapp

   Add:

   .. code-block:: text

      /var/www/bookingapp/logs/*.log {
          weekly
          rotate 4
          compress
          delaycompress
          missingok
          notifempty
          create 0640 www-data www-data
      }

2. **Database Maintenance**:

   For SQLite:

   .. code-block:: bash

      # Add to monthly cron
      0 4 1 * * sqlite3 /var/www/bookingapp/database.db 'VACUUM;'

3. **Application Updates**:

   .. code-block:: bash

      cd /var/www/bookingapp
      git pull
      source venv/bin/activate
      pip install -r requirement.txt
      sudo systemctl restart bookingapp