# docs/source/development/architecture.rst

================
Architecture
================

This document explains the architecture of the BookingApp system, including its components, layers, and their interactions.

Architecture Overview
-------------------

The BookingApp follows a layered architecture pattern with a clear separation of concerns:

1. **Presentation Layer**: HTML templates and JavaScript frontend
2. **API Layer**: FastAPI routes and endpoints
3. **Service Layer**: Business logic implementation
4. **Data Access Layer**: Database operations
5. **Infrastructure Layer**: Database, email notifications, etc.

.. image:: /_static/architecture_diagram.png
   :alt: Architecture Diagram
   :width: 100%

Component Architecture
--------------------

The system is composed of the following main components:

API Components
~~~~~~~~~~~~~

- **AccountManager**: Handles user authentication, registration, and account management
- **BookingManager**: Manages room bookings, cancellations, and sharing

Data Components
~~~~~~~~~~~~~

- **DatabaseManager**: Provides database access methods and manages the connection
- **Data Models**: User, Room, Booking, Building, Facility, etc.

Service Components
~~~~~~~~~~~~~~~

- **NotificationManager**: Handles email notifications for various events

Infrastructure Components
~~~~~~~~~~~~~~~~~~~~~

- **SQLite Database**: Stores application data
- **SMTP Service**: Sends email notifications

Layered Architecture
------------------

Presentation Layer
~~~~~~~~~~~~~~~~

The presentation layer consists of:

- **HTML Templates**: Located in the `template` directory
- **CSS Styles**: Located in the `static` directory
- **JavaScript**: Client-side functionality in the `static` directory

This layer is responsible for rendering the user interface and handling user interactions.

API Layer
~~~~~~~~

The API layer is implemented with FastAPI and consists of:

- **API Routes**: Defined in `account.py` and `booking.py`
- **Request/Response Models**: Using Python dataclasses
- **Input Validation**: Handled by FastAPI and custom validation logic

This layer exposes endpoints for the frontend to interact with the backend services.

Service Layer
~~~~~~~~~~~

The service layer contains the business logic of the application:

- **Account Logic**: User authentication, registration, and management
- **Booking Logic**: Room booking, cancellation, and sharing
- **Notification Logic**: Email notification generation and sending

Data Access Layer
~~~~~~~~~~~~~~

The data access layer handles database operations:

- **Database Manager**: Handles database connections and transactions
- **SQL Queries**: Executed via `aiosqlite`
- **Data Mapping**: Converts between database records and domain objects

Infrastructure Layer
~~~~~~~~~~~~~~~~~

The infrastructure layer provides the underlying services:

- **Database**: SQLite database for data storage
- **Email Service**: SMTP service for sending notifications
- **File System**: For static files and templates

Dataflow
-------

User Authentication Flow
~~~~~~~~~~~~~~~~~~~~~

1. User submits login form with credentials
2. Frontend sends request to `/account/login` endpoint
3. AccountManager validates credentials against database
4. If valid, a token is generated and returned
5. Frontend stores token in localStorage
6. Subsequent requests include the token for authentication

Room Booking Flow
~~~~~~~~~~~~~~

1. User selects a room and time slot in the booking calendar
2. Frontend sends request to `/booking/book` endpoint with token, room_id, datetime, and duration
3. BookingManager verifies token and checks room availability
4. If available, booking is created in the database
5. Booking confirmation notification is sent via email
6. Success response is returned to frontend with booking details
7. Frontend displays booking confirmation overlay

Booking Sharing Flow
~~~~~~~~~~~~~~~~~

1. User clicks "Share" on a booking
2. Frontend displays share overlay with share code
3. User shares the code with another user
4. Other user enters the share code in the "Add Shared Booking" field
5. Frontend sends request to `/booking/get_booking_by_share_code` endpoint
6. BookingManager finds the booking and adds it to the user's bookings
7. Success response is returned to frontend
8. Frontend refreshes to show the shared booking

Design Patterns
-------------

The application implements several design patterns:

Repository Pattern
~~~~~~~~~~~~~~~~

The DatabaseManager class implements the repository pattern, abstracting the data storage from the business logic:

.. code-block:: python

    async def get_user(self, token: str) -> Optional[User]:
        """Get user from authentication token."""
        async with self.conn.execute(
            """
            SELECT  u.username, u.email, u.role, u.user_id
            FROM User u 
            JOIN Authentication a ON u.user_id = a.user_id 
            WHERE a.token = ?
            """,
            (token,)
        ) as cur:
            if result := await cur.fetchone():
                return User(
                    username=result[0],
                    email=result[1],
                    id=result[3],
                    role=result[2]
                )
        return None

Factory Method Pattern
~~~~~~~~~~~~~~~~~~~

The dataclass constructors act as factory methods for creating domain objects:

.. code-block:: python

    @dataclass
    class Room:
        id: int
        name: str
        building_id: int
        type: Optional[str] = None
        capacity: Optional[int] = None
        facilities: Optional[list[Facility]] = None
        
        def to_dict(self):
            # Convert to dictionary representation
            return {
                "id": self.id,
                "name": self.name,
                "building_id": self.building_id,
                "type": self.type,
                "capacity": self.capacity,
                "facilities": [facility.to_dict() for facility in (self.facilities or [])],
            }

Observer Pattern
~~~~~~~~~~~~~

The notification system implements the observer pattern, where different events in the system trigger notifications:

.. code-block:: python

    # When a booking is created
    self.nm.booking_complete(booked_room, background_tasks=background_tasks)
    
    # When a booking is cancelled
    self.nm.booking_cancelled(booking, strikes, newStrike, background_tasks=background_tasks)
    
    # When a booking is edited
    self.nm.booking_edited(oldBooking, newBookedRoom, background_tasks=background_tasks)

Context Manager Pattern
~~~~~~~~~~~~~~~~~~~~

The DB class implements the context manager pattern for database connections:

.. code-block:: python

    class DB:
        def __init__(self):
            self.db = None

        async def __aenter__(self) -> "DatabaseManager":
            self.db = await DatabaseManager.create()
            return self.db

        async def __aexit__(self, exc_type, exc_val, traceback):
            if self.db:
                await self.db.close()

    # Usage
    async with DB() as db:
        user = await db.get_user(token)

Extension Points
--------------

The architecture includes several extension points where new functionality can be added:

1. **New API Endpoints**: Add new routes to existing manager classes or create new manager classes that extend the base API class

2. **Additional Data Models**: Define new dataclasses in `database.py` along with corresponding database methods

3. **New Notification Types**: Add new methods to the NotificationManager class for different types of notifications

4. **Enhanced Frontend Views**: Create new HTML templates and JavaScript modules for new features

5. **Database Schema Extensions**: Modify `create.sql` to add new tables or columns