# docs/source/development/database.rst

================
Database Schema
================

This document explains the database schema used in the BookingApp system, including tables, relationships, and data types.

Schema Overview
-------------

The BookingApp uses an SQLite database with the following main tables:

1. **User**: Stores user information and authentication details
2. **Authentication**: Manages user tokens for session handling
3. **Building**: Contains information about buildings
4. **Room**: Stores room details including capacity and type
5. **Booking**: Tracks all bookings with start times and durations
6. **User_Booking**: Links users to their bookings
7. **Facility**: Lists available facilities (projectors, whiteboards, etc.)
8. **Room_Facility**: Maps facilities to rooms
9. **University**: Stores university information
10. **User_University**: Links users to universities

.. image:: /_static/database_schema.png
   :alt: Database Schema Diagram
   :width: 100%

Table Definitions
---------------

The following sections describe each table in detail.

User Table
~~~~~~~~

Stores information about application users.

.. code-block:: sql

    CREATE TABLE User (
        user_id INTEGER PRIMARY KEY AUTOINCREMENT,
        university_id INTEGER REFERENCES University(university_id),
        username TEXT NOT NULL,
        password TEXT NOT NULL,
        email TEXT NOT NULL,
        verified INTEGER DEFAULT 0 CHECK (verified IN (0, 1)),
        phone_number TEXT,
        offence_count INTEGER CHECK (offence_count >= 0) DEFAULT 0,
        warning_type TEXT CHECK (warning_type IN ('none', 'minor', 'major')) DEFAULT 'none',
        role TEXT NOT NULL CHECK (role IN ('admin', 'user')) DEFAULT 'user'
    );

Fields:

- **user_id**: Unique identifier for each user
- **university_id**: Foreign key to the University table
- **username**: User's login name (typically their email address)
- **password**: Bcrypt hashed password
- **email**: User's email address
- **verified**: Flag indicating if the user's email is verified
- **phone_number**: Optional phone number
- **offence_count**: Counter for booking cancellation strikes
- **warning_type**: Warning level based on offence count
- **role**: User role, either 'admin' or 'user'

Authentication Table
~~~~~~~~~~~~~~~~~

Manages authentication tokens for user sessions.

.. code-block:: sql

    CREATE TABLE Authentication (
        token TEXT PRIMARY KEY,
        user_id INTEGER NOT NULL UNIQUE REFERENCES User(user_id),
        timestamp TEXT NOT NULL
    );

Fields:

- **token**: Unique token for authentication
- **user_id**: Foreign key to the User table
- **timestamp**: Token creation timestamp

Building Table
~~~~~~~~~~~

Stores information about buildings.

.. code-block:: sql

    CREATE TABLE Building (
        building_id INTEGER PRIMARY KEY AUTOINCREMENT,
        university_id INTEGER NOT NULL REFERENCES University(university_id),
        building_name TEXT NOT NULL,
        address_1 TEXT NOT NULL,
        address_2 TEXT,
        opening_time TEXT NOT NULL,
        closing_time TEXT NOT NULL CHECK (closing_time > opening_time)
    );

Fields:

- **building_id**: Unique identifier for each building
- **university_id**: Foreign key to the University table
- **building_name**: Name of the building
- **address_1**: First line of address
- **address_2**: Second line of address (optional)
- **opening_time**: Building opening time (HH:MM format)
- **closing_time**: Building closing time (HH:MM format)

Room Table
~~~~~~~~

Stores information about rooms.

.. code-block:: sql

    CREATE TABLE Room (
        room_id INTEGER PRIMARY KEY AUTOINCREMENT,
        building_id INTEGER NOT NULL REFERENCES Building(building_id),
        room_name TEXT NOT NULL,
        room_type TEXT NOT NULL CHECK (room_type IN ('study room', 'lecture room', 'computing room', 'lab')),
        room_capacity INTEGER NOT NULL CHECK (room_capacity > 0),
        room_availability_status TEXT NOT NULL CHECK (room_availability_status IN ('available', 'unavailable')) DEFAULT 'available'
    );

Fields:

- **room_id**: Unique identifier for each room
- **building_id**: Foreign key to the Building table
- **room_name**: Name or number of the room
- **room_type**: Type of room (study, lecture, computing, or lab)
- **room_capacity**: Maximum number of people the room can accommodate
- **room_availability_status**: Indicates if the room is generally available

Booking Table
~~~~~~~~~~

Stores information about room bookings.

.. code-block:: sql

    CREATE TABLE Booking (
        booking_id INTEGER PRIMARY KEY AUTOINCREMENT,
        building_id INTEGER NOT NULL REFERENCES Building(building_id),
        room_id INTEGER NOT NULL REFERENCES Room(room_id),
        start_time TEXT NOT NULL,
        duration TEXT NOT NULL, 
        access_code TEXT NOT NULL,
        share_code TEXT
    );

Fields:

- **booking_id**: Unique identifier for each booking
- **building_id**: Foreign key to the Building table
- **room_id**: Foreign key to the Room table
- **start_time**: Unix timestamp for booking start time
- **duration**: Duration in hours
- **access_code**: Code for accessing the room
- **share_code**: Code for sharing the booking with other users

User_Booking Table
~~~~~~~~~~~~~~~

Links users to their bookings.

.. code-block:: sql

    CREATE TABLE User_Booking (
        user_id INTEGER NOT NULL REFERENCES User(user_id),
        booking_id INTEGER NOT NULL REFERENCES Booking(booking_id),
        shared INTEGER DEFAULT 0 CHECK (shared IN (0, 1)),
        PRIMARY KEY (user_id, booking_id)
    );

Fields:

- **user_id**: Foreign key to the User table
- **booking_id**: Foreign key to the Booking table
- **shared**: Flag indicating if this is a shared booking (1) or primary booking (0)

Facility Table
~~~~~~~~~~~

Stores information about room facilities.

.. code-block:: sql

    CREATE TABLE Facility (
        facility_id INTEGER PRIMARY KEY AUTOINCREMENT,
        facility_name TEXT NOT NULL,
        facility_description TEXT
    );

Fields:

- **facility_id**: Unique identifier for each facility
- **facility_name**: Name of the facility
- **facility_description**: Description of the facility

Room_Facility Table
~~~~~~~~~~~~~~~~

Maps facilities to rooms.

.. code-block:: sql

    CREATE TABLE Room_Facility (
        room_id INTEGER NOT NULL REFERENCES Room(room_id),
        facility_id INTEGER NOT NULL REFERENCES Facility(facility_id),
        facility_availability_status TEXT NOT NULL CHECK (facility_availability_status IN ('available', 'unavailable')) DEFAULT 'available',
        facility_quantity INTEGER NOT NULL DEFAULT 1,
        facility_notes TEXT,
        PRIMARY KEY (room_id, facility_id)
    );

Fields:

- **room_id**: Foreign key to the Room table
- **facility_id**: Foreign key to the Facility table
- **facility_availability_status**: Indicates if the facility is available in the room
- **facility_quantity**: Number of units of the facility in the room
- **facility_notes**: Additional notes about the facility

University Table
~~~~~~~~~~~~~

Stores information about universities.

.. code-block:: sql

    CREATE TABLE University (
        university_id INTEGER PRIMARY KEY AUTOINCREMENT,
        university_name TEXT NOT NULL,
        address TEXT
    );

Fields:

- **university_id**: Unique identifier for each university
- **university_name**: Name of the university
- **address**: Address of the university

User_University Table
~~~~~~~~~~~~~~~~~

Links users to universities.

.. code-block:: sql

    CREATE TABLE User_University (
        user_id INTEGER NOT NULL REFERENCES User(user_id),
        university_id INTEGER NOT NULL REFERENCES University(university_id),
        status INTEGER DEFAULT 0 CHECK (status IN (0, 1)),
        PRIMARY KEY (user_id, university_id)
    );

Fields:

- **user_id**: Foreign key to the User table
- **university_id**: Foreign key to the University table
- **status**: Status of the association (0 = pending, 1 = approved)

Other Tables
~~~~~~~~~~

Additional tables for notifications and email verification:

.. code-block:: sql

    CREATE TABLE EmailVerification (
        verify_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        verification_code TEXT,
        created_at INTEGER,
        FOREIGN KEY(user_id) REFERENCES User(user_id) ON DELETE CASCADE
    );

    CREATE TABLE Notification (
        notification_id INTEGER PRIMARY KEY AUTOINCREMENT,
        booking_id INTEGER NOT NULL REFERENCES Booking(booking_id),
        notification_type TEXT NOT NULL CHECK (notification_type IN ('Email', 'SMS')) DEFAULT 'Email'
    );

    CREATE TABLE User_Notification (
        user_id INTEGER NOT NULL REFERENCES User(user_id),
        notification_id INTEGER NOT NULL REFERENCES Notification(notification_id),
        PRIMARY KEY (user_id, notification_id)
    );

Entity Relationships
-----------------

The database schema implements the following entity relationships:

One-to-Many Relationships
~~~~~~~~~~~~~~~~~~~~~~~

- One University has Many Buildings
- One Building has Many Rooms
- One User has Many Bookings (through User_Booking)
- One Room has Many Bookings

Many-to-Many Relationships
~~~~~~~~~~~~~~~~~~~~~~~~

- Many Users can have Many Bookings (through User_Booking)
- Many Rooms can have Many Facilities (through Room_Facility)
- Many Users can be associated with Many Universities (through User_University)
- Many Users can have Many Notifications (through User_Notification)

Indexing Strategy
---------------

The schema uses the following indexes for performance optimization:

Primary Keys
~~~~~~~~~~~

- All tables have primary keys for unique identification
- Junction tables use composite primary keys from their constituent foreign keys

Foreign Keys
~~~~~~~~~~

- Foreign keys are used to enforce referential integrity
- Foreign key constraints prevent orphaned records

Additional Indexes
~~~~~~~~~~~~~~~

While not explicitly defined in the schema, additional indexes would be beneficial for:

- User.username (for login lookups)
- Booking.start_time (for time-based queries)
- Building.university_id (for filtering buildings by university)
- Room.building_id (for filtering rooms by building)

Schema Evolution
--------------

The database schema is managed through SQL scripts:

- **create.sql**: Defines the initial schema
- **insert.sql**: Populates the database with initial data

To modify the schema:

1. Update the `create.sql` file with the schema changes
2. Create a migration script to update existing databases
3. Update the `database.py` module to reflect the changes in the data models

Example migration pattern:

.. code-block:: sql

    -- Example migration to add a new column
    ALTER TABLE Room ADD COLUMN room_floor INTEGER DEFAULT 1;
    
    -- Example migration to create a new table
    CREATE TABLE RoomReview (
        review_id INTEGER PRIMARY KEY AUTOINCREMENT,
        room_id INTEGER NOT NULL REFERENCES Room(room_id),
        user_id INTEGER NOT NULL REFERENCES User(user_id),
        rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
        comment TEXT,
        created_at INTEGER NOT NULL
    );