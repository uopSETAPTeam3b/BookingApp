# docs/source/development/extending.rst

================
Extending the Application
================

This document provides guidance on how to extend the BookingApp system with new features and functionality.

Adding a New Feature
------------------

Follow these steps to add a new feature to the application:

1. **Identify Requirements**: 
   
   - Define what the new feature should do
   - Determine which components need to be modified
   - Plan the user interface and interactions

2. **Update Database Schema**:

   If the feature requires new data storage:
   
   - Add new tables or columns to `create.sql`
   - Update the database models in `database.py`
   - Add new database access methods

   Example of adding a new table:

   .. code-block:: sql

      CREATE TABLE FeatureRequests (
          request_id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL REFERENCES User(user_id),
          request_title TEXT NOT NULL,
          request_description TEXT,
          status TEXT NOT NULL CHECK (status IN ('pending', 'approved', 'rejected')),
          created_at INTEGER NOT NULL
      );

3. **Add Backend Endpoints**:

   Create new API endpoints in the appropriate manager class:

   .. code-block:: python

      # In booking.py or a new feature-specific file
      self.router.add_api_route("/feature_requests", self.get_feature_requests, methods=["GET"])
      self.router.add_api_route("/feature_requests", self.create_feature_request, methods=["POST"])
      
      async def get_feature_requests(self, token: str) -> JSONResponse:
          async with DB() as db:
              if not await db.verify_token(token):
                  raise HTTPException(status_code=404, detail="User not found")
              
              feature_requests = await db.get_feature_requests(token)
              
              return JSONResponse(content={"feature_requests": feature_requests}, status_code=200)
      
      async def create_feature_request(self, request: FeatureRequestModel) -> JSONResponse:
          # Implementation...

4. **Create Frontend UI**:

   Add new HTML templates and JavaScript functionality:

   - Create a new HTML template in the `template` directory
   - Add JavaScript code in the `static` directory
   - Update CSS styles as needed

   Example HTML template (feature_requests.html):

   .. code-block:: html

      {% set page="feature_requests" %} {% include "nav.html" %}
      
      <main>
        <h1>Feature Requests</h1>
        
        <button id="createRequestBtn" class="main-button">Create New Request</button>
        
        <div id="requestFormContainer" class="hidden">
          <!-- Request form -->
        </div>
        
        <ul id="requestsList"></ul>
      </main>
      
      <script type="module" src="/feature_requests.js"></script>

5. **Implement Frontend Logic**:

   Create JavaScript code to interact with the backend:

   .. code-block:: javascript

      // feature_requests.js
      document.addEventListener("DOMContentLoaded", async () => {
          const token = localStorage.getItem("token");
          if (!token) {
              window.location.href = "/login";
              return;
          }
          
          await loadFeatureRequests(token);
          
          document.getElementById("createRequestBtn").addEventListener("click", () => {
              document.getElementById("requestFormContainer").classList.toggle("hidden");
          });
          
          // More event handlers...
      });
      
      async function loadFeatureRequests(token) {
          try {
              const response = await fetch(`/feature_requests?token=${token}`);
              const data = await response.json();
              
              // Display feature requests...
          } catch (error) {
              console.error("Error loading feature requests:", error);
          }
      }

6. **Update Navigation**:

   Add a link to the new feature in the navigation bar:

   .. code-block:: html

      <!-- In nav.html -->
      <button id="featureRequestsBtn">Feature Requests</button>

   .. code-block:: javascript

      // In nav.js
      document.getElementById("featureRequestsBtn").addEventListener("click", () => {
          window.location.href = "/feature_requests";
      });

7. **Add Tests**:

   Create tests for the new functionality:

   .. code-block:: python

      # In test.py
      def test_get_feature_requests():
          response = client.get(f"/feature_requests?token={token}")
          assert response.status_code == 200
          assert "feature_requests" in response.json()
      
      def test_create_feature_request():
          response = client.post("/feature_requests", json={
              "token": token,
              "title": "Test Request",
              "description": "This is a test feature request"
          })
          assert response.status_code == 200
          assert response.json().get("message") == "Feature request created successfully"

8. **Update Documentation**:

   Document the new feature in the appropriate documentation files.

Example: Adding a Room Rating System
----------------------------------

Let's walk through adding a room rating system:

1. **Database Changes**:

   .. code-block:: sql

      -- In create.sql
      CREATE TABLE RoomRating (
          rating_id INTEGER PRIMARY KEY AUTOINCREMENT,
          user_id INTEGER NOT NULL REFERENCES User(user_id),
          room_id INTEGER NOT NULL REFERENCES Room(room_id),
          rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
          comment TEXT,
          timestamp INTEGER NOT NULL,
          UNIQUE(user_id, room_id)
      );

2. **Database Methods**:

   .. code-block:: python

      # In database.py
      async def add_room_rating(self, user_id: int, room_id: int, rating: int, comment: str) -> bool:
          try:
              timestamp = int(time.time())
              await self.conn.execute(
                  """
                  INSERT INTO RoomRating (user_id, room_id, rating, comment, timestamp)
                  VALUES (?, ?, ?, ?, ?)
                  ON CONFLICT(user_id, room_id) DO UPDATE SET
                      rating = excluded.rating,
                      comment = excluded.comment,
                      timestamp = excluded.timestamp
                  """,
                  (user_id, room_id, rating, comment, timestamp)
              )
              await self.conn.commit()
              return True
          except Exception as e:
              print("Error adding room rating:", e)
              return False
      
      async def get_room_ratings(self, room_id: int) -> list:
          async with self.conn.execute(
              """
              SELECT r.rating_id, u.username, r.rating, r.comment, r.timestamp
              FROM RoomRating r
              JOIN User u ON r.user_id = u.user_id
              WHERE r.room_id = ?
              ORDER BY r.timestamp DESC
              """,
              (room_id,)
          ) as cur:
              results = await cur.fetchall()
              
              ratings = []
              for row in results:
                  ratings.append({
                      "id": row[0],
                      "username": row[1],
                      "rating": row[2],
                      "comment": row[3],
                      "timestamp": row[4]
                  })
              
              return ratings

3. **API Endpoints**:

   .. code-block:: python

      # In booking.py
      self.router.add_api_route("/rate_room", self.rate_room, methods=["POST"])
      self.router.add_api_route("/get_room_ratings", self.get_room_ratings, methods=["GET"])
      
      async def rate_room(self, token: str, room_id: int, rating: int, comment: str) -> JSONResponse:
          async with DB() as db:
              user = await db.get_user(token)
              if not user:
                  raise HTTPException(status_code=404, detail="User not found")
              
              success = await db.add_room_rating(user.id, room_id, rating, comment)
              
              if success:
                  return JSONResponse(content={"message": "Rating submitted successfully"}, status_code=200)
              else:
                  raise HTTPException(status_code=500, detail="Failed to submit rating")
      
      async def get_room_ratings(self, token: str, room_id: int) -> JSONResponse:
          async with DB() as db:
              if not await db.verify_token(token):
                  raise HTTPException(status_code=404, detail="User not found")
              
              ratings = await db.get_room_ratings(room_id)
              
              return JSONResponse(content={"ratings": ratings}, status_code=200)

4. **Frontend Implementation**:

   .. code-block:: javascript

      // In a new ratings.js file
      async function submitRating(roomId, rating, comment) {
          const token = localStorage.getItem("token");
          if (!token) return;
          
          try {
              const response = await fetch(`/booking/rate_room?token=${token}&room_id=${roomId}&rating=${rating}&comment=${comment}`, {
                  method: "POST"
              });
              
              const data = await response.json();
              
              if (response.ok) {
                  await loadRoomRatings(roomId);
                  return true;
              } else {
                  alert(data.detail || "Failed to submit rating");
                  return false;
              }
          } catch (error) {
              console.error("Error submitting rating:", error);
              return false;
          }
      }
      
      async function loadRoomRatings(roomId) {
          const token = localStorage.getItem("token");
          if (!token) return;
          
          try {
              const response = await fetch(`/booking/get_room_ratings?token=${token}&room_id=${roomId}`);
              const data = await response.json();
              
              if (response.ok) {
                  displayRatings(data.ratings);
              }
          } catch (error) {
              console.error("Error loading ratings:", error);
          }
      }
      
      function displayRatings(ratings) {
          const container = document.getElementById("ratingsContainer");
          container.innerHTML = "";
          
          if (ratings.length === 0) {
              container.innerHTML = "<p>No ratings yet</p>";
              return;
          }
          
          ratings.forEach(rating => {
              const ratingElement = document.createElement("div");
              ratingElement.classList.add("rating-item");
              
              const stars = "★".repeat(rating.rating) + "☆".repeat(5 - rating.rating);
              const date = new Date(rating.timestamp * 1000).toLocaleDateString();
              
              ratingElement.innerHTML = `
                  <div class="rating-stars">${stars}</div>
                  <div class="rating-user">${rating.username} - ${date}</div>
                  <div class="rating-comment">${rating.comment || ""}</div>
              `;
              
              container.appendChild(ratingElement);
          });
      }

5. **HTML UI**:

   .. code-block:: html

      <!-- Add to room details view -->
      <div class="ratings-section">
          <h3>Room Ratings</h3>
          
          <div class="rating-form">
              <div class="star-rating">
                  <span class="star" data-rating="1">☆</span>
                  <span class="star" data-rating="2">☆</span>
                  <span class="star" data-rating="3">☆</span>
                  <span class="star" data-rating="4">☆</span>
                  <span class="star" data-rating="5">☆</span>
              </div>
              
              <textarea id="ratingComment" placeholder="Your comments (optional)"></textarea>
              
              <button id="submitRatingBtn">Submit Rating</button>
          </div>
          
          <div id="ratingsContainer" class="ratings-list"></div>
      </div>

6. **CSS Styling**:

   .. code-block:: css

      /* In book.css or a new ratings.css file */
      .ratings-section {
          margin-top: 20px;
          border-top: 1px solid #ddd;
          padding-top: 20px;
      }
      
      .rating-form {
          margin-bottom: 20px;
      }
      
      .star-rating {
          font-size: 24px;
          color: #ccc;
          cursor: pointer;
      }
      
      .star-rating .star.selected,
      .rating-stars {
          color: gold;
      }
      
      .rating-item {
          border-bottom: 1px solid #eee;
          padding: 10px 0;
      }
      
      .rating-user {
          font-weight: bold;
          margin: 5px 0;
      }
      
      .rating-comment {
          font-style: italic;
      }

With these changes, users can now rate rooms and view ratings from other users.

Creating a New Module
------------------

If your feature is large enough, you might want to create a new module:

1. **Create a new Python file**:

   .. code-block:: python

      # ratings.py
      from api import API
      from fastapi.responses import JSONResponse
      from fastapi import HTTPException
      from database import DB, User
      from pydantic.dataclasses import dataclass
      
      class RatingManager(API):
          prefix = "/rating"
          
          def __init__(self):
              super().__init__()
              self.router.add_api_route("/rate", self.rate_item, methods=["POST"])
              self.router.add_api_route("/get", self.get_ratings, methods=["GET"])
              
          @dataclass
          class RatingRequest:
              token: str
              item_id: int
              item_type: str
              rating: int
              comment: str
          
          async def rate_item(self, rating: RatingRequest) -> JSONResponse:
              # Implementation...
              
          async def get_ratings(self, token: str, item_id: int, item_type: str) -> JSONResponse:
              # Implementation...

2. **Register the new module in app.py**:

   .. code-block:: python

      from ratings import RatingManager
      
      # Initialize and include the new router
      rating = RatingManager()
      app.include_router(rating.router)

Best Practices for Extensions
--------------------------

When extending the application, follow these best practices:

1. **Use the Existing Architecture**:
   
   - Follow the established pattern of API classes, database methods, and frontend components
   - Maintain separation of concerns between database access, business logic, and UI

2. **Validate User Input**:
   
   - Always validate user input on both frontend and backend
   - Use appropriate validation logic based on the data type
   - Sanitize input to prevent SQL injection and XSS attacks

3. **Test Thoroughly**:
   
   - Add test cases for each new feature
   - Test both success and error scenarios
   - Verify edge cases and boundary conditions

4. **Document Changes**:
   
   - Update documentation for new features
   - Add comments to complex code sections
   - Include usage examples and screenshots if appropriate

5. **Follow Naming Conventions**:
   
   - Use consistent naming for variables, methods, and classes
   - Follow the existing patterns in the codebase
   - Use descriptive names that reflect the purpose of each element

Common Extension Points
--------------------

The BookingApp has several common extension points:

1. **New Booking Features**:
   
   - Add recurring bookings
   - Implement booking approval workflows
   - Add different booking types (e.g., events, meetings)

2. **User Management Enhancements**:
   
   - Add user roles and permissions
   - Implement team/group functionality
   - Add profile customization options

3. **Room Management Features**:
   
   - Add room layout management
   - Implement equipment tracking
   - Create room maintenance schedules

4. **Reporting and Analytics**:
   
   - Add usage statistics
   - Implement booking trend analysis
   - Create export functionality for reports

5. **Integration Points**:
   
   - Connect to external calendar systems
   - Integrate with identity providers
   - Add payment processing for paid bookings

Suggested New Features
-------------------

Here are some specific features that would enhance the BookingApp:

1. **Room Reports**:
   
   Allow users to report issues with rooms, such as broken equipment or cleanliness problems.

2. **Booking Templates**:
   
   Let users save booking configurations as templates for quick reuse.

3. **Calendar Integration**:
   
   Integrate with Google Calendar, Outlook, or iCal to sync bookings.

4. **Mobile App**:
   
   Create a mobile app version using a framework like React Native or Flutter.

5. **Advanced Search**:
   
   Implement a more powerful search functionality for rooms and bookings.

6. **Booking Policies**:
   
   Add configurable booking policies like maximum duration or advance notice requirements.

7. **Meeting Notes**:
   
   Allow users to attach notes or minutes to bookings for record-keeping.

8. **QR Code Access**:
   
   Generate QR codes for room access instead of alphanumeric codes.

9. **Resource Booking**:
   
   Extend the system to allow booking of equipment alongside rooms.

10. **Interactive Maps**:
    
    Create interactive building maps for easier room selection.