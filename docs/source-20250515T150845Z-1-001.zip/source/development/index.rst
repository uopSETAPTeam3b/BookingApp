# docs/source/development/index.rst

=================
Developer Guide
=================

This section provides technical documentation for developers who wish to understand, modify, or extend the BookingApp system.

.. toctree::
   :maxdepth: 2

   architecture
   database
   frontend
   extending