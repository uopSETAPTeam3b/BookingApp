# docs/source/modules/app.rst

=======
app.py
=======

The `app.py` module is the entry point for the application. It initializes the FastAPI application, sets up the database, and includes the API routers.

Overview
--------

This module serves as the main application entry point. It initializes the FastAPI application, sets up the database connection, registers API routes, and defines static file serving. It also handles environment-specific configuration such as testing mode detection.

Module Structure
---------------

.. code-block:: python

    import os
    from fastapi import FastAPI, Request
    from fastapi.responses import FileResponse
    from fastapi.templating import Jinja2Templates

    from account import AccountManager
    from booking import BookingManager
    from database import DatabaseManager
    from notification import NotificationManager

    # Initialize database
    CREATE_FILE="src/create.sql"
    INSERT_FILE="src/insert.sql"
    DatabaseManager(create=CREATE_FILE, insert=INSERT_FILE)

    # Create FastAPI application
    app = FastAPI()

    # Configure static paths based on environment
    if os.environ.get("PYTEST_VERSION") is not None:
        STATIC = "static"
        DatabaseManager("database_test.db")
    else:
        STATIC = "static"

    # Initialize notification manager
    notif = NotificationManager()

    # Set up API routers
    account = AccountManager(notif)
    app.include_router(account.router)
    booking = BookingManager(notif)
    app.include_router(booking.router)

    # Configure templates
    BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    TEMPLATE = "template"
    templates = Jinja2Templates(os.path.join(BASE_DIR, TEMPLATE))

    # Default 404 response
    R_404 = FileResponse(
        os.path.join(STATIC, "404.html"), status_code=404
    )

Static File Serving
-----------------

The module defines a catch-all route for serving static files and HTML templates:

.. code-block:: python

    @app.get("/{path:path}")
    def index(request: Request, path):
        template_file_path = os.path.abspath(os.path.join(TEMPLATE, path))
        
        # Check if path is a template
        if os.path.exists(template_file_path):
            if os.path.isdir(template_file_path):
                if os.path.exists(f"{template_file_path}/index.html"):
                    return templates.TemplateResponse(
                        f"{path}/index.html", {"request": request}
                    )
            else:
                return templates.TemplateResponse(path, {"request": request})
        elif os.path.exists(template_file_path + ".html"):
            return templates.TemplateResponse(path + ".html", {"request": request})

        # If not a template, try static file
        file_path = os.path.abspath(os.path.join(STATIC, path if path else "index.html"))
        if not os.path.exists(file_path):
            return R_404
        if not os.path.isfile(file_path):
            if os.path.exists(f"{file_path}/index.html"):
                return FileResponse(f"{file_path}/index.html")
            return R_404
        return FileResponse(file_path)

Configuration
------------

The module includes several configuration settings:

- **Database Configuration**: SQL files for database schema and initial data
- **Static Files Path**: Location of static assets
- **Templates Path**: Location of HTML templates
- **Test Mode Detection**: Special configuration for test environment

Dependencies
-----------

The module has the following dependencies:

- `os`: For file path handling and environment variables
- `fastapi`: For the web framework
- `fastapi.responses.FileResponse`: For serving static files
- `fastapi.templating.Jinja2Templates`: For template rendering
- `account.AccountManager`: For account-related API endpoints
- `booking.BookingManager`: For booking-related API endpoints
- `database.DatabaseManager`: For database connection and initialization
- `notification.NotificationManager`: For email notifications

Starting the Application
----------------------

The application can be started using the FastAPI CLI:

.. code-block:: bash

    fastapi run ./src/app.py

Or with uvicorn directly:

.. code-block:: bash

    uvicorn src.app:app --reload