# docs/source/modules/index.rst

==================
Module Documentation
==================

This section provides detailed documentation for the key modules of the BookingApp system.

.. toctree::
   :maxdepth: 2

   account
   api
   app
   booking
   database
   notification