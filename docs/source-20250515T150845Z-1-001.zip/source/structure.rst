# docs/source/structure.rst

=====================
Repository Structure
=====================

The repository is organized into the following main directories:

.. code-block:: none

    BookingApp/
    ├── docs/                      # Documentation files
    │   ├── Makefile               # Sphinx documentation build file
    │   ├── make.bat               # Windows build script
    │   ├── requirements.txt       # Documentation dependencies
    │   └── source/                # RST documentation source files
    ├── src/                       # Source code
    │   ├── account.py             # Account management functionality
    │   ├── api.py                 # Base API class
    │   ├── app.py                 # Main application entry point
    │   ├── booking.py             # Booking management functionality
    │   ├── create.sql             # SQL for database schema creation
    │   ├── database.py            # Database access and models
    │   ├── insert.sql             # SQL for initial data insertion
    │   ├── notification.py        # Email notification system
    │   └── test.py                # Unit tests
    ├── static/                    # Static assets (CSS, JS, images)
    │   ├── *.css                  # CSS files
    │   ├── *.js                   # JavaScript files
    │   └── *.svg                  # SVG images
    ├── template/                  # HTML templates
    │   ├── account.html           # Account management page
    │   ├── book.html              # Room booking page
    │   ├── booking.html           # View bookings page
    │   └── ...                    # Other template files
    ├── .gitignore                 # Git ignore file
    ├── .readthedocs.yaml          # Read the Docs configuration
    ├── LICENSE                    # MIT license file
    ├── README.md                  # Project overview and team info
    └── requirement.txt            # Project dependencies

Source Code Structure
====================

src/
----

The `src` directory contains all the Python source code for the application:

- **account.py**: User authentication and account management
- **api.py**: Base API class for route definitions
- **app.py**: Main application entry point
- **booking.py**: Room booking functionality
- **create.sql**: SQL schema definition
- **database.py**: Database access and models
- **insert.sql**: Initial data for the database
- **notification.py**: Email notification system
- **test.py**: Unit tests

static/
-------

The `static` directory contains frontend assets:

- **CSS files**: Stylesheets for the application
- **JavaScript files**: Client-side functionality
- **SVG images**: Vector graphics for icons and UI elements

template/
---------

The `template` directory contains HTML templates:

- **account.html**: User account management page
- **book.html**: Room booking interface
- **booking.html**: Booking management page
- **confirmation_overlay.html**: Booking confirmation dialog
- **login.html**: User login page
- **nav.html**: Navigation component
- **signup.html**: User registration page
- **welcome.html**: Welcome page

Configuration Files
==================

- **.gitignore**: Specifies files to be ignored by Git
- **.readthedocs.yaml**: Configuration for Read the Docs documentation hosting
- **LICENSE**: MIT license file
- **README.md**: Project overview and team information
- **requirement.txt**: Python dependencies for the project