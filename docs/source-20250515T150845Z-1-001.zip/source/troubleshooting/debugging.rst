# docs/source/troubleshooting/debugging.rst

================
Debugging Techniques
================

This document provides debugging techniques for the BookingApp system to help developers identify and fix issues.

General Debugging Approach
------------------------

When troubleshooting issues with the BookingApp system, follow these general steps:

1. **Identify the issue**: Gather information about the problem, including error messages, unexpected behaviors, and steps to reproduce.

2. **Isolate the component**: Determine whether the issue is in the frontend, backend, or database.

3. **Check logs**: Review server logs, browser console logs, and application logs for relevant error messages.

4. **Test in isolation**: Create a minimal test case that reproduces the issue.

5. **Apply fixes**: Make targeted changes to resolve the issue.

6. **Verify the solution**: Confirm that the issue is resolved and no new issues are introduced.

Backend Debugging
---------------

Python Debugging
~~~~~~~~~~~~~~

1. **Print statements**: Add temporary print statements to track execution flow and variable values:

   .. code-block:: python

      print(f"Processing booking {booking_id} with parameters: {params}")
      
      # For complex objects, use pretty printing
      import pprint
      pprint.pprint(complex_object)

2. **Logging**: Use the Python logging module for more structured debugging:

   .. code-block:: python

      import logging
      
      # Set up logging
      logging.basicConfig(
          level=logging.DEBUG,
          format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
          filename='app.log'
      )
      
      # Create a logger
      logger = logging.getLogger(__name__)
      
      # Log messages
      logger.debug("Debug message")
      logger.info("Info message")
      logger.warning("Warning message")
      logger.error("Error message")
      logger.critical("Critical message")

3. **Interactive debugging**: Use Python's built-in debugger:

   .. code-block:: python

      import pdb
      
      def problematic_function():
          # Code...
          pdb.set_trace()  # Execution will pause here
          # More code...

4. **Exception handling**: Add more detailed exception handling to identify issues:

   .. code-block:: python

      try:
          # Code that might raise an exception
          result = await db.execute_query()
      except Exception as e:
          print(f"Error type: {type(e).__name__}")
          print(f"Error message: {str(e)}")
          import traceback
          traceback.print_exc()
          raise  # Re-raise the exception

Database Debugging
~~~~~~~~~~~~~~~~

1. **SQLite CLI**: Use the SQLite command-line interface to directly query the database:

   .. code-block:: bash

      sqlite3 database.db
      
      # Display schema
      .schema
      
      # List tables
      .tables
      
      # Run a query
      SELECT * FROM User LIMIT 5;

2. **Query logging**: Log SQL queries and parameters:

   .. code-block:: python

      async def execute_query(self, query, params=None):
          print(f"Executing query: {query}")
          print(f"With parameters: {params}")
          
          try:
              if params:
                  result = await self.conn.execute(query, params)
              else:
                  result = await self.conn.execute(query)
              
              print("Query executed successfully")
              return result
          except Exception as e:
              print(f"Query error: {e}")
              raise

3. **Data inspection**: Add functions to dump database contents:

   .. code-block:: python

      async def debug_dump_table(self, table_name):
          """Dump the contents of a table for debugging."""
          async with self.conn.execute(f"SELECT * FROM {table_name}") as cursor:
              rows = await cursor.fetchall()
              
              # Get column names
              columns = [description[0] for description in cursor.description]
              
              print(f"=== {table_name} ===")
              print(columns)
              for row in rows:
                  print(row)

API Endpoint Debugging
~~~~~~~~~~~~~~~~~~~

1. **API testing tools**: Use tools like curl, Postman, or HTTPie to test API endpoints:

   .. code-block:: bash

      # Using curl
      curl -X POST "http://localhost:8000/account/login" \
          -H "Content-Type: application/json" \
          -d '{"username": "test@example.com", "password": "password123"}'
      
      # Using HTTPie
      http POST http://localhost:8000/account/login \
          username=test@example.com password=password123

2. **Response inspection**: Add detailed responses for debugging:

   .. code-block:: python

      async def debug_endpoint(self, param: str) -> JSONResponse:
          try:
              # Process request
              result = await self.process_data(param)
              
              # Return detailed response
              return JSONResponse(
                  content={
                      "status": "success",
                      "data": result,
                      "debug_info": {
                          "param_type": type(param).__name__,
                          "result_type": type(result).__name__,
                          "timestamp": time.time()
                      }
                  },
                  status_code=200
              )
          except Exception as e:
              return JSONResponse(
                  content={
                      "status": "error",
                      "message": str(e),
                      "error_type": type(e).__name__,
                      "traceback": traceback.format_exc()
                  },
                  status_code=500
              )

Frontend Debugging
----------------

JavaScript Debugging
~~~~~~~~~~~~~~~~~

1. **Console logging**: Use the browser console for debugging:

   .. code-block:: javascript

      // Basic logging
      console.log("Message");
      
      // Object inspection
      console.log("Data:", data);
      
      // Formatted logging
      console.log("User %s logged in at %s", username, new Date().toISOString());
      
      // Structured logging
      console.log({
          event: "booking_created",
          bookingId: booking.id,
          userId: user.id,
          timestamp: new Date().toISOString()
      });

2. **Debugger statement**: Use the debugger statement to pause execution:

   .. code-block:: javascript

      function problematicFunction() {
          // Code...
          debugger;  // Execution will pause here if dev tools are open
          // More code...
      }

3. **Function tracing**: Log function entry and exit points:

   .. code-block:: javascript

      function tracedFunction(arg1, arg2) {
          console.log(`Entering tracedFunction with args: ${arg1}, ${arg2}`);
          
          try {
              // Function body
              const result = doSomething(arg1, arg2);
              console.log(`Exiting tracedFunction with result: ${result}`);
              return result;
          } catch (error) {
              console.error(`Error in tracedFunction: ${error}`);
              throw error;
          }
      }

4. **Performance profiling**: Measure function execution time:

   .. code-block:: javascript

      function measurePerformance(func, ...args) {
          console.time('Function execution');
          const result = func(...args);
          console.timeEnd('Function execution');
          return result;
      }
      
      // Usage
      const result = measurePerformance(expensiveFunction, arg1, arg2);

Network Debugging
~~~~~~~~~~~~~~

1. **Fetch request logging**: Log details of fetch requests:

   .. code-block:: javascript

      async function loggedFetch(url, options = {}) {
          console.log(`Fetching ${url} with options:`, options);
          
          try {
              const startTime = Date.now();
              const response = await fetch(url, options);
              const endTime = Date.now();
              
              console.log(`Received response from ${url} in ${endTime - startTime}ms:`, {
                  status: response.status,
                  statusText: response.statusText,
                  headers: Object.fromEntries([...response.headers]),
              });
              
              // Clone the response to be able to log its body
              const responseClone = response.clone();
              
              try {
                  const data = await responseClone.json();
                  console.log(`Response data from ${url}:`, data);
              } catch (e) {
                  console.log(`Response from ${url} is not JSON`);
              }
              
              return response;
          } catch (error) {
              console.error(`Error fetching ${url}:`, error);
              throw error;
          }
      }

2. **Network monitor**: Use the browser's network tab to inspect requests:
   
   - Open browser developer tools (F12 or right-click > Inspect)
   - Go to the Network tab
   - Perform the action that's causing issues
   - Examine the request and response headers, body, and status

3. **Mock responses**: Create mock responses for testing:

   .. code-block:: javascript

      // Mock fetch implementation
      window.originalFetch = window.fetch;
      
      window.fetch = async function(url, options) {
          console.log(`Intercepted fetch to ${url}`);
          
          // Mock specific endpoints
          if (url.includes('/api/bookings')) {
              console.log('Returning mock bookings data');
              return {
                  ok: true,
                  status: 200,
                  json: async () => ({ bookings: mockBookingsData })
              };
          }
          
          // Pass through to real fetch for everything else
          return window.originalFetch(url, options);
      };
      
      // Restore original fetch when done
      function restoreFetch() {
          window.fetch = window.originalFetch;
      }

DOM Debugging
~~~~~~~~~~~

1. **Element inspection**: Log DOM elements and their properties:

   .. code-block:: javascript

      function inspectElement(selector) {
          const element = document.querySelector(selector);
          
          if (!element) {
              console.error(`Element not found: ${selector}`);
              return;
          }
          
          console.log('Element:', element);
          console.log('Classes:', element.classList);
          console.log('Attributes:', element.attributes);
          console.log('Style:', element.style);
          console.log('Computed style:', window.getComputedStyle(element));
          console.log('Dimensions:', {
              offsetWidth: element.offsetWidth,
              offsetHeight: element.offsetHeight,
              clientWidth: element.clientWidth,
              clientHeight: element.clientHeight,
              scrollWidth: element.scrollWidth,
              scrollHeight: element.scrollHeight
          });
          console.log('Position:', {
              offsetLeft: element.offsetLeft,
              offsetTop: element.offsetTop,
              getBoundingClientRect: element.getBoundingClientRect()
          });
          
          return element;
      }

2. **Event listeners**: Monitor events on elements:

   .. code-block:: javascript

      function monitorEvents(selector, events = ['click', 'focus', 'blur', 'input', 'change']) {
          const element = document.querySelector(selector);
          
          if (!element) {
              console.error(`Element not found: ${selector}`);
              return;
          }
          
          const handlers = {};
          
          events.forEach(eventName => {
              const handler = event => {
                  console.log(`Event ${eventName} on ${selector}:`, event);
              };
              
              element.addEventListener(eventName, handler);
              handlers[eventName] = handler;
          });
          
          // Return a function to remove the event listeners
          return function stopMonitoring() {
              events.forEach(eventName => {
                  element.removeEventListener(eventName, handlers[eventName]);
              });
              console.log(`Stopped monitoring events on ${selector}`);
          };
      }
      
      // Usage
      const stopMonitoring = monitorEvents('#submitButton');
      // Later, when done
      stopMonitoring();

3. **DOM change tracking**: Track changes to specific DOM elements:

   .. code-block:: javascript

      function trackDOMChanges(selector) {
          const element = document.querySelector(selector);
          
          if (!element) {
              console.error(`Element not found: ${selector}`);
              return;
          }
          
          const observer = new MutationObserver((mutations) => {
              mutations.forEach(mutation => {
                  console.log('DOM change detected:', {
                      type: mutation.type,
                      target: mutation.target,
                      addedNodes: mutation.addedNodes,
                      removedNodes: mutation.removedNodes,
                      attributeName: mutation.attributeName,
                      oldValue: mutation.oldValue
                  });
              });
          });
          
          observer.observe(element, {
              attributes: true,
              childList: true,
              subtree: true,
              characterData: true,
              attributeOldValue: true,
              characterDataOldValue: true
          });
          
          return observer;
      }

Debugging Tools
-------------

Browser Developer Tools
~~~~~~~~~~~~~~~~~~~~

Modern browsers provide powerful developer tools:

1. **Element Inspector**: View and modify the DOM and CSS
2. **Console**: Execute JavaScript and view logged messages
3. **Network**: Monitor network requests and responses
4. **Sources**: Debug JavaScript code with breakpoints
5. **Application**: Inspect localStorage, sessionStorage, cookies, etc.
6. **Performance**: Analyze page performance
7. **Memory**: Identify memory leaks

SQLite Browser
~~~~~~~~~~~~

SQLite Browser is a visual tool for working with SQLite databases:

1. **Install**: Download from https://sqlitebrowser.org/
2. **Open Database**: Open the database.db file
3. **Browse Data**: View and edit table contents
4. **Execute SQL**: Run custom SQL queries
5. **Modify Structure**: View and modify the database schema

HTTP Request Tools
~~~~~~~~~~~~~~~

Tools for testing API endpoints:

1. **Postman**: GUI tool for API testing
2. **Insomnia**: Alternative to Postman with a simpler interface
3. **curl**: Command-line tool for making HTTP requests
4. **HTTPie**: User-friendly command-line HTTP client

Common Debugging Scenarios
-----------------------

1. **Authentication Issues**:

   - Check local storage for token: `localStorage.getItem("token")`
   - Verify token in the database: `SELECT * FROM Authentication WHERE token = ?`
   - Monitor login network requests to check request body and response

2. **Booking Creation Problems**:

   - Track the request payload: `console.log("Booking payload:", payload)`
   - Check for overlapping bookings in the database
   - Verify date/time conversions: `console.log("Timestamp:", timestamp, "Date:", new Date(timestamp * 1000))`

3. **UI Rendering Issues**:

   - Inspect element properties: `console.log("Element:", element, "Style:", window.getComputedStyle(element))`
   - Check if data is loaded: `console.log("Data received:", data)`
   - Monitor DOM updates with MutationObserver

4. **Performance Problems**:

   - Measure function execution time: `console.time('Function'); /* code */ console.timeEnd('Function');`
   - Check database query performance: `EXPLAIN QUERY PLAN SELECT * FROM...`
   - Use the Performance tab in browser developer tools

Debugging Best Practices
---------------------

1. **Start Simple**: Begin with the simplest explanation and solution
2. **One Change at a Time**: Make one change at a time to isolate its effect
3. **Be Methodical**: Follow a systematic approach rather than random changes
4. **Document Findings**: Record what you learn for future reference
5. **Use Version Control**: Make debugging changes in a separate branch
6. **Ask for Help**: Don't hesitate to ask colleagues for assistance
7. **Take Breaks**: Fresh eyes often see solutions more clearly