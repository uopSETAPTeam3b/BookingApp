# docs/source/user/features.rst

========
Features
========

This page provides an overview of the key features available in the BookingApp system.

Room Booking
-----------

- **Calendar View**: Visual calendar showing room availability by time slot
- **Building Selection**: Filter rooms by building
- **Date Selection**: Choose booking dates using the date picker
- **Time Slot Selection**: Select start time and duration for bookings
- **Filtering Options**:
  - Room type (study room, lecture room, computing room, lab)
  - Room capacity
  - Available facilities (projector, whiteboard, etc.)
  - Time range
- **Booking Confirmation**: Immediate confirmation with access code
- **Email Notifications**: Automated emails for booking confirmations

Booking Management
----------------

- **Booking List**: View all your current and past bookings
- **Booking Details**: See room information, time, date, and access code
- **Booking Actions**:
  - Cancel bookings
  - Edit bookings (change room, time, or duration)
  - Share bookings with other users
- **Shared Bookings**: Access bookings shared by other users
- **Past Bookings**: View history of previous bookings
- **Share Codes**: Generate and use share codes for booking access

Account Management
----------------

- **Profile Management**: View and update account details
- **University Affiliation**: Request to join a university
- **Verification**: Email verification for account security
- **Strike System**: Tracks late cancellations and no-shows
- **Admin Functions**: University access request management (for admin users)

User Interface
------------

- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Dark Mode**: Toggle between light and dark themes
- **Navigation Bar**: Easy access to all main functions
- **Overlays**: Interactive dialogs for booking confirmations and actions
- **Accessibility**: Design considerations for all users

Email Notifications
-----------------

- **Welcome Email**: Sent when a new user account is created
- **Booking Confirmation**: Sent when a booking is created
- **Booking Cancellation**: Sent when a booking is cancelled
- **Booking Edited**: Sent when a booking is modified
- **Booking Shared**: Sent when a booking is shared with another user
- **Strike Notification**: Sent when a user receives a strike for late cancellation

Security Features
---------------

- **Token-based Authentication**: Secure login system
- **Password Hashing**: Bcrypt encryption for passwords
- **Input Validation**: Protection against invalid data
- **Cross-Site Scripting Protection**: Prevention of XSS attacks
- **Rate Limiting**: Protection against brute force attacks

Future Features
-------------

These features are planned for future releases:

- **Calendar Integration**: Sync with Google Calendar, Outlook, etc.
- **Mobile App**: Native mobile applications
- **Advanced Booking Rules**: Priority booking, booking quotas, etc.
- **Interactive Floor Plans**: Visual selection of rooms from building maps
- **Resource Booking**: Book equipment alongside rooms